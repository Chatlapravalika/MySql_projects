
Employee Payroll System - MySQL Project

Description:
This project manages employee salary details using MySQL.
It supports employee data storage, salary calculation, and reports.

Features:
- Employee management
- Salary calculation
- Payroll report
- MySQL queries with joins

Tools Used:
- MySQL
- SQL

Usage:
1. Import the SQL file into MySQL
2. Run queries to view payroll details

Suitable For:
- College projects
- GitHub portfolio
- Beginners
