
-- Employee Payroll System Database

CREATE DATABASE payroll_system;
USE payroll_system;

CREATE TABLE employees (
    emp_id INT PRIMARY KEY AUTO_INCREMENT,
    emp_name VARCHAR(100),
    department VARCHAR(50),
    designation VARCHAR(50),
    basic_salary DECIMAL(10,2)
);

CREATE TABLE payroll (
    payroll_id INT PRIMARY KEY AUTO_INCREMENT,
    emp_id INT,
    hra DECIMAL(10,2),
    da DECIMAL(10,2),
    tax DECIMAL(10,2),
    net_salary DECIMAL(10,2),
    FOREIGN KEY (emp_id) REFERENCES employees(emp_id)
);

INSERT INTO employees (emp_name, department, designation, basic_salary)
VALUES
('Ravi Kumar', 'IT', 'Developer', 40000),
('Anita Sharma', 'HR', 'Manager', 45000);

INSERT INTO payroll (emp_id, hra, da, tax, net_salary)
VALUES
(1, 5000, 3000, 4000, 44000),
(2, 6000, 3500, 4500, 50000);

SELECT e.emp_name, e.department, p.net_salary
FROM employees e
JOIN payroll p ON e.emp_id = p.emp_id;
