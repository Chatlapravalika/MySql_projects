
Student Management System - MySQL Project

This project manages student records using MySQL.

Tables:
1. Students
2. Courses
3. Marks

Features:
- Store student details
- Course management
- Marks tracking
- Uses Primary & Foreign Keys

How to Use:
1. Open MySQL
2. Import student_management.sql
3. Run queries

Suitable for:
- College mini project
- DBMS lab
- Resume project
