
CREATE DATABASE StudentManagement;
USE StudentManagement;

CREATE TABLE Students (
    Student_ID INT PRIMARY KEY AUTO_INCREMENT,
    Name VARCHAR(100),
    Department VARCHAR(50),
    Year INT,
    Email VARCHAR(100)
);

CREATE TABLE Courses (
    Course_ID INT PRIMARY KEY AUTO_INCREMENT,
    Course_Name VARCHAR(100),
    Credits INT
);

CREATE TABLE Marks (
    Mark_ID INT PRIMARY KEY AUTO_INCREMENT,
    Student_ID INT,
    Course_ID INT,
    Marks INT,
    FOREIGN KEY (Student_ID) REFERENCES Students(Student_ID),
    FOREIGN KEY (Course_ID) REFERENCES Courses(Course_ID)
);

INSERT INTO Students VALUES
(1,'Rahul','CSE',3,'rahul@gmail.com'),
(2,'Anita','ECE',2,'anita@gmail.com');

INSERT INTO Courses VALUES
(101,'DBMS',4),
(102,'OS',3);

INSERT INTO Marks VALUES
(1,1,101,85),
(2,2,102,78);
