
-- View all available rooms
SELECT * FROM rooms WHERE status = 'Available';

-- Booking details
SELECT c.name, r.room_type, b.check_in, b.check_out
FROM bookings b
JOIN customers c ON b.customer_id = c.customer_id
JOIN rooms r ON b.room_id = r.room_id;
