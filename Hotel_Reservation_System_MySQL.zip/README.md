
Hotel Reservation System – MySQL Project

Features:
- Room management
- Customer management
- Booking system

Concepts Used:
- Primary & Foreign Keys
- Joins
- Stored Procedures

How to Run:
1. Run schema.sql
2. Run insert_data.sql
3. Execute queries.sql
4. Optional: procedures_triggers.sql
