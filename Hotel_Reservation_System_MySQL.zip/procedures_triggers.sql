
DELIMITER //

CREATE PROCEDURE BookRoom(
    IN cust_id INT,
    IN r_id INT,
    IN checkin DATE,
    IN checkout DATE
)
BEGIN
    INSERT INTO bookings (customer_id, room_id, check_in, check_out)
    VALUES (cust_id, r_id, checkin, checkout);

    UPDATE rooms SET status='Booked' WHERE room_id = r_id;
END //

DELIMITER ;
