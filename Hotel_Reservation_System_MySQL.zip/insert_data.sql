
INSERT INTO rooms (room_type, price_per_night, status) VALUES
('Single', 1500, 'Available'),
('Double', 2500, 'Available'),
('Suite', 5000, 'Available');

INSERT INTO customers (name, phone, email) VALUES
('Rahul Sharma', '9876543210', 'rahul@gmail.com'),
('Anita Verma', '9123456780', 'anita@gmail.com');

INSERT INTO bookings (customer_id, room_id, check_in, check_out) VALUES
(1, 1, '2026-01-10', '2026-01-12');
