CREATE DATABASE school;
USE school;