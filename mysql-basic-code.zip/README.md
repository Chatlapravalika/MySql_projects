# MySQL Basic Code for Beginners

This repository contains basic MySQL commands for beginners.

## Topics Covered
- Create Database
- Create Tables
- Insert Data
- Select Queries
- Update Records
- Delete Records
- Aggregate Functions

## Tools Used
- MySQL
- MySQL Workbench
