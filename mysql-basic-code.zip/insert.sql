INSERT INTO students (name, age, course)
VALUES
('Ravi', 20, 'Computer Science'),
('Anu', 21, 'IT'),
('Kiran', 22, 'Data Science');