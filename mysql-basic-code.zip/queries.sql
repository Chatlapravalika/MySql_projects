SELECT * FROM students;
SELECT * FROM students WHERE age > 20;
UPDATE students SET course = 'AI' WHERE id = 1;
DELETE FROM students WHERE id = 3;
SELECT COUNT(*) FROM students;
SELECT AVG(age) FROM students;