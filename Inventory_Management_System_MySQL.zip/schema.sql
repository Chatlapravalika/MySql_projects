
CREATE DATABASE inventory_db;
USE inventory_db;

CREATE TABLE suppliers (
    supplier_id INT AUTO_INCREMENT PRIMARY KEY,
    supplier_name VARCHAR(100),
    contact VARCHAR(50)
);

CREATE TABLE products (
    product_id INT AUTO_INCREMENT PRIMARY KEY,
    product_name VARCHAR(100),
    supplier_id INT,
    price DECIMAL(10,2),
    stock INT,
    FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id)
);
