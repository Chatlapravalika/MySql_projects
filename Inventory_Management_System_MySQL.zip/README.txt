
Inventory Management System - MySQL Project

Files Included:
1. schema.sql - Database and table creation
2. data.sql - Sample data insertion
3. queries.sql - Useful queries

How to Run:
1. Open MySQL
2. Run schema.sql
3. Run data.sql
4. Run queries.sql
