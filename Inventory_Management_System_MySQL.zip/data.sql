
INSERT INTO suppliers (supplier_name, contact) VALUES
('ABC Traders', '9876543210'),
('XYZ Supplies', '9123456789');

INSERT INTO products (product_name, supplier_id, price, stock) VALUES
('Keyboard', 1, 500.00, 50),
('Mouse', 2, 300.00, 100);
