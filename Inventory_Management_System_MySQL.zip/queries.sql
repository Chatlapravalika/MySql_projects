
-- View all products with suppliers
SELECT p.product_name, s.supplier_name, p.price, p.stock
FROM products p
JOIN suppliers s ON p.supplier_id = s.supplier_id;

-- Low stock products
SELECT * FROM products WHERE stock < 20;

-- Update stock
UPDATE products SET stock = stock - 1 WHERE product_id = 1;
